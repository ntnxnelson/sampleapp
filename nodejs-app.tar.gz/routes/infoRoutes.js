var express = require('express');
var os = require('os');

module.exports = function() {
    var router = express.Router();

    router.get('/', function(req, res) {
        var interfaces = os.networkInterfaces();
        var ip = '127.0.0.1';

        Object.keys(interfaces).some(function(name) {
            return interfaces[name].some(function(iface) {
                if (iface.family === 'IPv4' && !iface.internal) {
                    ip = iface.address;
                    return true;
                }
                return false;
            });
        });

        res.json({
            ip: ip,
            hostname: os.hostname()
        });
    });

    return router;
};
