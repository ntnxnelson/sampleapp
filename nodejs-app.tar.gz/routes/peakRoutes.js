var express = require('express');

module.exports = function(Peak) {
    var router = express.Router();
    var searchableFields = ['rank', 'peak', 'elevation', 'state', 'range'];

    router.get('/', async function(req, res) {
        try {
            var filter = {};
            searchableFields.forEach(function(field) {
                if (req.query[field] !== undefined) {
                    filter[field] = req.query[field];
                }
            });
            var peaks = await Peak.find(filter);
            res.json(peaks);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    });

    router.post('/', async function(req, res) {
        try {
            var peak = new Peak({
                rank: req.body.rank,
                peak: req.body.peak,
                elevation: req.body.elevation,
                state: req.body.state,
                range: req.body.range
            });
            var savedPeak = await peak.save();
            res.status(201).json(savedPeak);
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    });

    return router;
};
