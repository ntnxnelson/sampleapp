#!/usr/bin/env node

var express = require('express'),
    mongoose = require('mongoose');
var Peak = require('./models/peakModel');
var app = express();
var port = process.env.PORT || 3000;
var mongodbHost = process.env.MONGODB_HOST || 'localhost';

mongoose.connect('mongodb://' + mongodbHost + ':27017/demodb')
    .then(function() {
        console.log('Connected to MongoDB at ' + mongodbHost);
    })
    .catch(function(err) {
        console.error('MongoDB connection error:', err.message);
    });

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
});

var peakRouter = require('./routes/peakRoutes')(Peak);
var infoRouter = require('./routes/infoRoutes')();
app.use('/api/peaks', peakRouter);
app.use('/api/info', infoRouter);

app.get('/', function(req, res) {
    res.send('API is functional.');
});

module.exports = app.listen(port, function() {
    console.log('Running on port: ' + port);
});
